<ul>
  <li>
    <a href="home.php">
      <i class="glyphicon glyphicon-home"></i>
      <span>الرئيسية</span>
    </a>
  </li>
  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-th-list"></i>
       <span>المبيعات</span>
      </a>
      <ul class="nav submenu">
         <li><a href="sales.php">ادارة المبيعات</a> </li>
         <li><a href="add_sale.php">اضافة بيع جديد</a> </li>
     </ul>
  </li>
  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-signal"></i>
       <span>التقارير</span>
      </a>
      <ul class="nav submenu">
        <li><a href="sales_report.php">التقارير حسب التاريخ </a></li>
        <li><a href="monthly_sales.php">التقارير الشهرية</a></li>
        <li><a href="daily_sales.php">التقارير اليومية</a> </li>
      </ul>
  </li>
</ul>
