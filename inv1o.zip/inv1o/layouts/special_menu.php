<ul>
  <li>
    <a href="home.php">
      <i class="glyphicon glyphicon-home"></i>
      <span>الرئيسية</span>
    </a>
  </li>
  <li>
    <a href="categorie.php" >
      <i class="glyphicon glyphicon-indent-left"></i>
      <span>التصنيفات</span>
    </a>
  </li>
  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-th-large"></i>
      <span>المنتجات</span>
    </a>
    <ul class="nav submenu">
       <li><a href="product.php">ادارة المنتجات</a> </li>
       <li><a href="add_product.php">ااضافة منتج جديد</a> </li>
   </ul>
  </li>
  <li>
    <a href="media.php" >
      <i class="glyphicon glyphicon-picture"></i>
      <span>الصور</span>
    </a>
  </li>
</ul>
